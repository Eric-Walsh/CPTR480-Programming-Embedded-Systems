#include "MKL25Z4.h"

void Init_PIT(unsigned period);

void Start_PIT(void);

void Stop_PIT(void);

void PIT_IRQHandler(void);
