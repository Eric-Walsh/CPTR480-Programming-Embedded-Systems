#include "MKL25z4.h"

void init_UART2();

void UART2_Transmit(uint32_t data);