#include <MKL25Z4.H>

void Init_TPM(int32_t function);

void init_dist_TPM0();