#include <MKL25Z4.H>

void delayMicros(uint32_t n);

void init_ultrasound();

uint32_t measure_distance();