#include "MKL25z4.h"

void init_Mag(void);

uint32_t get_Mag_Status();

uint32_t get_XData();

uint32_t get_YData();

uint32_t get_ZData();
