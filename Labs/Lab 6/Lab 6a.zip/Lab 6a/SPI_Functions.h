#include "MKL25z4.h"
#include "gpio_defs.h"

void init_SPI1(void);

uint8_t Test_SPIsend(uint8_t data);

void Test_SPI_Loopback(void);
