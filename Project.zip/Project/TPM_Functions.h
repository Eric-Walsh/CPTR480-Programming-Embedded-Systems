#include <MKL25Z4.H>

void init_TPM(void);
