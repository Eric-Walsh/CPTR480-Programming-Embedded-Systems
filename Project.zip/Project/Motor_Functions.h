#include "MKL25z4.h"

void right_wheel_forward();
	
void left_wheel_forward();

void right_wheel_stop();
	
void left_wheel_stop();
	
void go_Forward();

void go_Backward();

void stop();
	
void turn_Left();
	
void turn_Right();

void right_wheel_backward();

void left_wheel_backward();