void Test_Motors(int val);

void Test_Mag();

void Test_UART();

void Test_ADC();

void Test_USound();