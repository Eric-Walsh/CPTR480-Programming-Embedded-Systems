#include "MKL25Z4.h"

void Init_ADC(void);

void ADC_IRQHandler(void);

void scan_ADC(uint32_t *array);
